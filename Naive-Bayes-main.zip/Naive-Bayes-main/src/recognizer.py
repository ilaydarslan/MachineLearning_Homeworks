from hmmlearn import hmm
import numpy as np

# EV Model
model_ev = hmm.MultinomialHMM(n_components=2)

model_ev.startprob_ = np.array([1.0, 0.0])

model_ev.transmat_ = np.array([
    [0.6, 0.4],
    [0.2, 0.8]
])

model_ev.emissionprob_ = np.array([
    [0.7, 0.3],
    [0.1, 0.9]
])


# OKUL Model
model_okul = hmm.MultinomialHMM(n_components=3)

model_okul.startprob_ = np.array([1.0,0.0,0.0])

model_okul.transmat_ = np.array([
    [0.6,0.4,0.0],
    [0.2,0.6,0.2],
    [0.1,0.2,0.7]
])

model_okul.emissionprob_ = np.array([
    [0.6,0.4],
    [0.5,0.5],
    [0.2,0.8]
])

# test observation
test_data = np.array([[0,1,1]]).T


def classify(observation):

    score_ev = model_ev.score(observation)
    score_okul = model_okul.score(observation)

    if score_ev > score_okul:
        return "EV"
    else:
        return "OKUL"


print("Predicted word:", classify(test_data))
