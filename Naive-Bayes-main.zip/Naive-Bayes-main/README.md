# HMM-Speech-Recognition

This project implements a simple isolated word recognition system using Hidden Markov Models (HMM).

Words modeled:
EV
OKUL

Libraries:
hmmlearn
numpy

Steps:
1. Two HMM models are created
2. Observation sequences are generated
3. The model with the highest likelihood classifies the word

The Viterbi algorithm is also manually calculated in the report.
